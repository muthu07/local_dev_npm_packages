# Browsersync UI [![Build Status](https://travis-ci.org/BrowserSync/UI.svg?branch=master)](https://travis-ci.org/BrowserSync/UI)

Comes bundled with the Browsersync module (version `2.0.0` onwards). 

## License
Copyright (c) 2016 Shane Osbourne
Licensed under the Apache 2.0 license.
