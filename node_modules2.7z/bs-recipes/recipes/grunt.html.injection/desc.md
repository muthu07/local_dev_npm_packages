
To see the live HTML injecting, along with CSS injection, simply perform changes to either `index.html` or `css/main.css`