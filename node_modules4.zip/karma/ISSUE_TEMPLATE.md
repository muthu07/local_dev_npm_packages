### Expected behaviour

### Actual behaviour

### Environment Details

- Karma version (output of `karma --version`):
- Relevant part of your `karma.config.js` file

### Steps to reproduce the behaviour

1.
2.
3.
