#!/bin/sh

rm -vrf ${TMPDIR}/{foo,tmp,something,complicated,clike,using}*
