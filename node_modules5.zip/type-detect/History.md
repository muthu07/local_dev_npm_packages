
0.1.1 / 2013-10-10 
==================

 * Merge pull request #2 from strongloop/fix-browserify
 * index,test: support browserify

0.1.0 / 2013-08-14 
==================

 * readme: document all methods
 * readme: add badges
 * library: [test] ensure test runs
 * travis: change script to run coveralls reportwq
 * tests: add tests
 * lib: add type detect lib
 * pkg: prepare for coverage based tests
 * "Initial commit"
